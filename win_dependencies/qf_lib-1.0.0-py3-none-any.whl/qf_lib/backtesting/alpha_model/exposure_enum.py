from enum import Enum


class Exposure(Enum):
    LONG = 1.0
    OUT = 0.0
    SHORT = -1.0
