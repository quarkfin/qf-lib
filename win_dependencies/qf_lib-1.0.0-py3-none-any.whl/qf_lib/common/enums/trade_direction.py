from enum import Enum


class TradeDirection(Enum):
    Buy = 0
    Sell = 1
