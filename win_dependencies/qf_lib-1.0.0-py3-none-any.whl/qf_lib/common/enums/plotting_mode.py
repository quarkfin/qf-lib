from enum import Enum


class PlottingMode(Enum):
    PDF = 1
    Web = 2