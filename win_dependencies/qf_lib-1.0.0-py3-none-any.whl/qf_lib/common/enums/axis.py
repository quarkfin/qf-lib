from enum import Enum


class Axis(Enum):
    X = 0
    Y = 1
