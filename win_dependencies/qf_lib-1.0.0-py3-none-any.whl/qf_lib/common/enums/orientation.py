from enum import Enum


class Orientation(Enum):
    Horizontal = 0
    Vertical = 1
