def expected_growth_rate(expected_return: float, expected_volatility: float):
    return expected_return - 0.5 * expected_volatility**2
