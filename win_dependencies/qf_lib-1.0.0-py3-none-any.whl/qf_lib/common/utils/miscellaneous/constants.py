BUSINESS_DAYS_PER_YEAR = 250
DAYS_PER_YEAR_AVG = 365.2425

HIGHCHART_DASH_STYLES = {"dashed": "Dash", "solid": "Solid", "dashdot": "DashDot", "-": "Solid",
                         "--": "Dash", "-.": "DashDot"}
HIGHCHART_COLORS = {"b": "blue", "r": "red", "g": "green", "o": "orange"}
