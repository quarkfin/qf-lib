# -*- coding: utf-8 -*-
r"""
auxiliary function for main Haver package functions

@author: Haver Analytics
"""

import os
from datetime import date, datetime
import re
import pandas as pd
import pdb
import warnings

from Haver import _HaverPkgError, _HaverPkgWarning

# field order corresponds to output DataFrames, not to API order
# field types also correspond to default types in HMDF output
# note the presence of 'group'
#          absence  of 'alias'
const_fields = ('database',
                'code',
                'startdate',
                'enddate',
                'frequency',
                'descriptor',
                'numobs',
                'datetimemod',
                'magnitude',
                'decprecision',
                'diftype',
                'aggtype',
                'datatype',
                'group',
                'geography1',
                'geography2',
                'shortsource',
                'longsource')
const_fields_cell = ('database',
                     'code',
                     'frequency',
                     'aggtype',
                     'datatype',
                     'group',
                     'geography1',
                     'geography2',
                     'descriptor',
                     'shortsource',
                     'longsource')
const_fields_numeric = ('numobs',
                        'magnitude',
                        'decprecision',
                        'diftype')
const_fields_datetime = ('startdate',
                         'enddate',
                         'datetimemod')
const_fields_hmdtable = ('database',
                         'code',
                         'startdate',
                         'enddate',
                         'frequency',
                         'descriptor',
                         'numobs',
                         'datetimemod',
                         'magnitude',
                         'decprecision',
                         'diftype',
                         'aggtype',
                         'datatype',
                         'group',
                         'geography1',
                         'geography2',
                         'shortsource',
                         'longsource')
# excludes fields no longer used
const_fields_dlx = ('VarVame',
                    'StartDate',
                    'EndDate',
                    'NumberObs',
                    'Frequency',
                    'DateTimeMod',
                    'Magnitude',
                    'DecPrecision',
                    'DifType',
                    'AggType',
                    'DataType',
                    'Geography1',
                    'Geography2',
                    'Descriptor',
                    'ShortSource',
                    'LongSource')


const_freq_str   = ('daily', 'weekly', 'monthly', 'quarterly', 'annual')
const_freq_str6  = ('daily', 'weekly', 'monthly', 'quarterly', 'annual', 'yearly')
const_freq_char  = ('d', 'w', 'm', 'q', 'a')
const_freq_dlx   = (60 , 55 , 40 , 30 , 10)
const_freq_tru   = (365 , 52 , 12 , 4 , 1)

const_freqe_str  = ('daily', 'weekly', 'monthly', 'quarterly', 'annual',
                    'weekly', 'weekly', 'weekly', 'weekly', 'weekly', 'weekly')
const_freqe_pds  = ('B' , 'W' , 'M' , 'Q' , 'A',   # pandas frequency strings
                    'W-MON', 'W-TUE', 'W-WED', 'W-THU', 'W-FRI', 'W-SAT', 'W-SUN')
    # "e": extended
const_freqe_char = ('d', 'w', 'm', 'q', 'a',
                    'w', 'w', 'w', 'w', 'w', 'w', 'w')
const_freqe_dlx  = (60 , 55 , 40 , 30 , 10 ,
                    51 , 52 , 53 , 54 , 55 , 56 , 57)
const_freqe_tru  = (365 , 52 , 12 , 4 , 1,
                    52, 52, 52, 52, 52, 52, 52)
                                   
const_map_freq_d2c = dict(zip(const_freqe_dlx , const_freqe_char))
    # dict args: keys, values
const_map_freq_c2d = dict(zip(const_freq_char , const_freq_dlx))
const_map_freq_d2s = dict(zip(const_freqe_dlx , const_freqe_str))
const_map_freq_s2d = dict(zip(const_freq_str  , const_freq_dlx))
const_map_freq_c2s = dict(zip(const_freq_char , const_freq_str))

const_map_freq_t2c = dict(zip(const_freq_tru , const_freq_char))
const_map_freq_d2t = dict(zip(const_freqe_dlx, const_freqe_tru))
const_map_freq_t2d = dict(zip(const_freq_tru , const_freq_dlx))
const_map_freq_d2p = dict(zip(const_freqe_dlx , const_freqe_pds))

const_aggtype_num = (1, 2, 3, 9, 0)
const_aggtype_str = ('AVG', 'SUM', 'EOP', 'NDF', 'NST')
const_map_aggtype_n2s = dict(zip(const_aggtype_num, const_aggtype_str))
const_map_aggtype_s2n = dict(zip(const_aggtype_str, const_aggtype_num))

const_aggmode_num = (1, 2, 3)
const_aggmode_str = ('strict', 'relaxed', 'force')
const_map_aggmode_s2n = dict(zip(const_aggmode_str, const_aggmode_num))
const_map_aggmode_n2s = dict(zip(const_aggmode_num, const_aggmode_str))

const_query_errortypes = ('codes.found',
                          'database.access',
                          'codes.notfound',
                          'metadata.access', )
const_limit_numcodes      = 5000
const_limit_numdatapoints = 15000000


def stringCheck(charvec, allowed=None):
    """stringCheck(charvec, varargin)

    auxiliary def for main Haver package functions:
    checks that input strings for Haver package defs do not contained:
      chars that are not permitted. Returns True/False.
    
    stringcheck(charvec, allowed) checks that charvec does not contain
         characters that are not alphanumeric and that are not contained in
         string 'allowed'.
    stringcheck(charvec)
         assumes 'allowed' to be the empty string.
    'charvec' may only have alphanumeric characters.
    'allowed' must be a string of length >=1.

    returns True if prohibited chars are not contained in elems of charvec
    """

    missing_allowed = False
    if allowed is None:
        missing_allowed = True
        allowed = ''

    if type(charvec)==tuple:
        charvec = list(charvec)

    if type(charvec)==str:
        charvec = list([charvec])
    elif type(charvec)==list:
        for curcode in charvec:
            if type(curcode)!=str:
                raise _HaverPkgError('(Haveraux.stringCheck) Input list has '
                                'non-string elements.')
    else:
        raise _HaverPkgError('(Haveraux.stringCheck) Type of input arg ''charvec'' '
                        'must be either string, tuple or list.')

    allowed_list = '!not $§#&=<>-_.:@'
    if not missing_allowed:
        if type(allowed)!=str:
            raise _HaverPkgError('(Haveraux.stringCheck) arg ''allowed'' incorrectly specified.')
        if set(allowed)-set(allowed_list)!=set():
            raise _HaverPkgError('(Haveraux.stringCheck) One or more elements of '
                             'arg ''allowed'' not admitted.')
    mypat = ''.join(set(allowed) & set(allowed_list))
    mypat = '^[0-9a-zA-Z' + mypat + ']*$'
    for curcode in charvec:
        matches = re.findall(mypat, curcode)
        if len(matches)==0:
            return False
    return True



def dtToYmd(dt):
    """dtToYmd(dt)

    auxiliary def for main Haver package functions:
    converts a datetime.date object to a ymddate string
    ymddates are (Y)YYMMDD, e.g. 1010630 <> 30jun2001 , 990131 <> 31jan1999

    """
    ymd = int(dt.strftime('%Y%m%d')) - 19000000
    return ymd


def ymdToDt(ymd):
    """ymdToDt(ymd)

    auxiliary def for main Haver package functions:
    converts a list of ymddate strings to a list of datetime.date objects
    ymddates are (Y)YYMMDD, e.g. 1010630 <> 30jun2001 , 990131 <> 31jan1999

    """

    dt = [date(int(x/10000)+1900, int((x % 10000)/100), int(x % 100)) for x in ymd]
    return dt


def freqChar(freqin, numtype='dlxfreq'):
    """freqChar(freqin, varargin)

    auxiliary def for main Haver package functions:
    Description: converts freq specified by (true) freq number or DLX number or string to single char:
       freqin: valid DLX frequency:
            freq number: 365   52     12      4         1
            DLX number:  60    51-57  40      30        10
            string:      daily weekly monthly quarterly annual
            char:        d     w      m       q         a
       numtype: one of 'dlxfreq' or 'trufreq'
    Notes: - if freq is already a single char, it is unchanged.:
    Example(s):
       haver.freqChar(12, 'trufreq')   returns: 'm'
       haver.freqChar(40)              returns: 'm'
       haver.freqChar(12)              returns: error  (numtype='dlxfreq' is default)
       haver.freqChar('quarterly')     returns: 'q'

    """
    
    if not isinstance(freqin, (str, int, float)):
        raise _HaverPkgError('(Haveraux.freqChar) Invalid argument type for ''freqin''.')

    if type(freqin)==str:
        freqin = freqin.lower()

    if type(numtype)!=str or numtype.lower() not in ('trufreq', 'dlxfreq'):
        raise _HaverPkgError('(Haveraux.freqChar) Input arg ''numtype'' incorrectly specified.')
    numtype = numtype.lower()

    # char -> char
    if type(freqin)==str and len(freqin) == 1:
        try:
            charout = const_map_freq_c2d[freqin]
        except KeyError:
            raise _HaverPkgError('(Haveraux.freqChar) Value for arg ''freqin'' not recognized.')
        return freqin

    # string -> char
    if type(freqin)==str and len(freqin)>1:
        try:
            charout = const_map_freq_s2d[freqin]
        except: # KeyError:
            raise _HaverPkgError('(Haveraux.freqChar) Value for arg ''freqin'' not recognized.')
        return freqin[0]
    elif isinstance(freqin, (int, float)):

    # dlxfreq -> char
        if numtype=='dlxfreq':
            try:
                charout = const_map_freq_d2c[freqin]
            except: # KeyError:
                raise _HaverPkgError('(Haveraux.freqChar) Value for arg ''freqin'' not recognized.')
            return charout

        elif numtype=='trufreq':
    # trufreq -> char
            try:
                charout = const_map_freq_t2c[freqin]
            except KeyError:
                raise _HaverPkgError('(Haveraux.freqChar) Value for arg ''freqin'' not recognized.')
            return charout

    raise _HaverPkgError('(Haveraux.freqChar) Input arg freqin not recognized.')


def freqString(freqin):
    r"""
    Description: converts freqChar to freqString
       freqin: valid frequency character
            char:        d     w      m       q         a
            string:      daily weekly monthly quarterly annual
    Notes: - if freqin is already a string, it is unchanged.
    Example(s): 
       haver.freqChar('quarterly')   returns: 'quarterly'
       haver.freqChar('q')           returns: 'quarterly'
    """
    
    if not type(freqin)==str:
        raise _HaverPkgError('(Haveraux.freqString) Input argument must be a string.')

    freqin = freqin.lower()
    
    # string -> string
    if len(freqin) > 1:
        try:
            charout = const_map_freq_s2d[freqin]
        except KeyError:
            raise _HaverPkgError('(Haveraux.freqString) Value for arg ''freqin'' not recognized.')
        return freqin

    # char -> string
    if len(freqin) == 1:
        try:
            charout = const_map_freq_c2s[freqin]
        except KeyError:
            raise _HaverPkgError('(Haveraux.freqString) Value for arg ''freqin'' not recognized.')
        return charout

    raise _HaverPkgError('(Haveraux.freqString) Value for arg ''freqin''' \
                     'not recognized.')


def freqNumeric(freqin, freqfrom=None, freqto=None):
    """freqNumeric(freqin, freqfrom, freqto)

    auxiliary def for main Haver package functions:
    Description: converts numeric trufreq to numeric dlxfreq and vice versa, and coverts char to trufreq or dlxfreq
       freqin: valid numeric trufreq or numeric dlxfreq, or char
       freqfrom:   one of 'dlxfreq' or 'trufreq'
       freqto:     one of 'dlxfreq' or 'trufreq'
    Returns:
       valid numeric trufreq or numeric dlxfreq, or char
    Notes: - if args 'freqfrom' and 'freqto' are identical, 'freqin' is returned unchanged:
    Example(s):
       haver.freqNumeric('q',  freqto='dlxfreq')    returns: 30
       haver.freqNumeric('D',  freqto='trufreq')    returns: 365
       haver.freqNumeric(12,'trufreq','dlxfreq')    returns: 40
       haver.freqNumeric(12,'dlxfreq','trufreq')    returns: error
       haver.freqNumeric(60,'dlxfreq','trufreq')    returns: 365

    """
    missing_from = (freqfrom is None)
    missing_to   = (freqto is None)

    if isinstance(freqin, (int, float)):
        if (missing_from or missing_to):
            raise _HaverPkgError('(Haveraux.freqNumeric): Numeric arg ''freqin'' requires args ''freqfrom'' and ''freqto''.')
    elif type(freqin)==str:
        if (len(freqin) != 1):
            raise _HaverPkgError('(Haveraux.freqNumeric) Character arg ''freqin'' must consist of a single character.')
        if (missing_to):
            raise _HaverPkgError('(Haveraux.freqNumeric) Character arg ''freqin'' requires arg ''freqto''.')
        freqin = freqin.lower()

    if (not missing_from):
        freqfrom = freqfrom.lower()
        if freqfrom not in {'dlxfreq','trufreq'}:
            raise _HaverPkgError('(Haveraux.freqNumeric) Input arg ''freqfrom'' invalid.')
    freqto = freqto.lower()
            
    if isinstance(freqin, (int, float)):
        if freqfrom=='dlxfreq':
            try:
                numout = const_map_freq_d2t[freqin]
            except KeyError:
                raise _HaverPkgError('(Haveraux.freqNumeric) Input arg freqin not a valid dlxfreq.')
            if freqto=='dlxfreq':
                numout = freqin
        elif freqfrom=='trufreq':
            try:
                numout = const_map_freq_t2d[freqin]
            except KeyError:
                raise _HaverPkgError('(Haveraux.freqNumeric) Input arg freqin not a valid trufreq.')
            if freqto=='trufreq':
                numout = freqin
    elif type(freqin)==str:
        try:
            numout = const_map_freq_c2d[freqin]
        except KeyError:
            raise _HaverPkgError('(Haveraux.freqNumeric) Value for arg ''freqin'' not recognized.')
        if freqto=='trufreq':
            numout = const_map_freq_d2t[numout]

    return numout

def decodeMetadata(tblin):
# auxiliary function for main Haver toolbox functions
# 
# input is DataFrame object
# decodes the numeric encoding for frequency and aggtype

    freqvec = tblin['frequency']
    ufreq   = set(freqvec)

    for curfreq in ufreq:
        curfreq = int(curfreq) # this is was numpy.int64 (?)
        curfreqstr = freqChar(curfreq).upper()
        freqvec = [curfreqstr if x==curfreq else x for x in freqvec]

    tblin.loc[:, 'frequency'] = freqvec

    aggvec = tblin['aggtype']
    uagg   = set(aggvec)
    aggmap = const_map_aggtype_n2s
    for curagg in uagg:
        curagg = int(curagg)
        curaggstr = aggmap[curagg]
        aggvec = [curaggstr if x==curagg else x for x in aggvec]

    tblin.loc[:, 'aggtype'] = aggvec
   
    return None
    
def hasfullcodes(dfin):
    """hasfullcodes(dfin)

    auxiliary def for main Haver package functions:
    checks whether the passed object has full Haver code specifications:
    requirements are:
      - class DataFrame with columns 'database' and 'code'
      - cols must be of type str, have at least one entry, entries
        w/ alphanumerics plus one colon only, and may not have empty strings

    """

    if not isinstance(dfin, pd.core.frame.DataFrame):
        return False

    if len(dfin)==0:
        return False

    if not all([x in dfin.columns.tolist() for x in ['database', 'code']]):
        return False
    if dfin.code.dtype!='O' or dfin.database.dtype!='O':
        return False
    
    codes     = list(dfin['code'])
    databases = list(dfin['database'])
    if type(codes[0])!=str or type(databases[0])!=str:
        return False
    if len([x for x in codes if len(x)==0])>0 or len([x for x in databases if len(x)==0])>0:
        return False
    if not stringCheck(databases, '') or not stringCheck(codes, ''):
        return False

    return True

# ------------- FUNCTIONS SPECIFIC TO PYTHON --------------------------------

def abbrevMatch(abbrev, tokens):
    if type(abbrev)!=str or not isinstance(tokens, (list, set, tuple)):
        raise _HaverPkgError('(Haveraux.abbrevMatch) invalid input arg types')
    matches = [x for x in tokens if re.findall('^'+abbrev, x)]
    if len(matches)==0:
        raise _HaverPkgError('(Haveraux.abbrevMatch) no match found.')
    elif len(matches)>=2:
        raise _HaverPkgError('(Haveraux.abbrevMatch) more than one match found.')
    
    return matches[0]
               
#def uniqOrder(lin):
## returns unique elems of list in order of occurrence
#    lout = []
#    for x in lin:
#        if x not in lout:
#            lout.append(x)
#
#    # # Alternatively:
#    # uniqset = set(lin)
#    # lout = [x for x in lin if x in uniqset]
#    
#    return lout

def uniqOrder(lin, idfun=None): 
# returns unique elems of list in order of occurrence
    seen = {}
    result = []
    for item in lin:
        if item in seen: continue
        seen[item] = 1
        result.append(item)
    return result

def api_raiseError(errnum):
    print('errnum ' + str(errnum))
    if errnum==1:
        errmsg = '(API:databaseAccess) Unable to open database'
    elif errnum==2:
        errmsg = '(API:varNotFound) Unable to find variable name'
    elif errnum==3:
        errmsg = '(API:varMetaData) Unable to load variable information'
    elif errnum==4:
        errmsg = '(API:varSourceInfo) Unable to load source information'
    elif errnum==11:
        errmsg = '(API:databaseAccess) Unable to re-open database'
    elif errnum==20:
        errmsg = '(API) Unable to set aggregation mode'
#    elif errnum==21:
#    elif errnum==22:
#    elif errnum==23:
#    elif errnum==24:
#    elif errnum==25:
#    elif errnum==26:
    elif errnum==100:
        errmsg = '(API:PythonCMismatch) Number of codes expected by Python not equal to number of codes in database.'
    else:
        errmsg = '(API) Unknown error.'

    raise _HaverPkgError(errmsg)

def warn(message):
    def warnFormat(message, category, filename, lineno, file=None, line=None):
        return '  {2}: {3}\n\n'.format(filename, lineno, category.__name__, message)
    
    oldwarn = warnings.formatwarning
    warnings.formatwarning = warnFormat
    warnings.warn(message, category=_HaverPkgWarning)
    warnings.formatwarning = oldwarn
