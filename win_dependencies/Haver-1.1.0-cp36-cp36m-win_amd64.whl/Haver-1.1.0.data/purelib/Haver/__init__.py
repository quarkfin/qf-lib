# -*- coding: utf-8 -*-
r"""
Query data and metadata from Haver Analytics databases

Author: Haver Analytics

If you are new to the Haver package, we recommend consulting
Section :ref:`Introduction_to_the_Haver_Package_for_Python` of the
Haver Python Reference available in the client section of
http://www.haver.com. If you want to jump straight to function
documentation, see the help entries for :ref:`Haver_data` and
:ref:`Haver_metadata`.

See Also
^^^^^^^^

All functions and objects from the Haver package:

* :ref:`Haver.data() <Haver_data>` : query time series data from Haver Analytics databases
* :ref:`Haver.metadata() <Haver_metadata>` : query time series metadata from Haver Analytics databases
* :ref:`Haver_DataFrame` : return type of ``Haver.data()``
* :ref:`Haver_Meta_DataFrame` : return type of ``Haver.metadata()``
* :ref:`Haver_ErrorReport_dictionary` : return type for incorrectly specified queries
* :ref:`Haver.path() <Haver_path>` : set and query the path to Haver databases
* :ref:`Haver.databases() <Haver_databases>` : print or return list of Haver Analytics databases
* :ref:`Haver.limits() <Haver_limits>` : set and get limits for Haver Analytics data queries
* :ref:`Haver.codelists() <Haver_codelists>` : extract lists of Haver series codes
* :ref:`Haver.verbose() <Haver_verbose>` : set verbose message mode of Haver functions to ``True`` or ``False``
"""

__version__ = '1.1.0'

__all__ = ["data", "metadata", "path", 
           "databases", "limits", "codelists", "verbose",
           "hasfullcodes"]
# __all__ = ["data"]

class _HaverPkgError(Exception):
    pass

class _HaverPkgWarning(UserWarning):
    pass

from ._Haver    import path, metadata, data, databases, limits, codelists, verbose, _haverdbpath_init, cversion
from ._Haveraux import hasfullcodes

_haverdbpath_init(__path__[0])


