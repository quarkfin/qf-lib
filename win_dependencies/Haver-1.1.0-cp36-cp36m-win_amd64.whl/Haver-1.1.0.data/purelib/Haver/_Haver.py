# -*- coding: utf-8 -*-
r"""
Query data and metadata from Haver Analytics databases

@author: Haver Analytics
"""

import os
import Haver._Haveraux as Haveraux
import warnings
import glob
from datetime import date, datetime
import pandas as pd
import pdb
import numpy as np
import ctypes as ct
import math
import keyword
import pickle
import platform
import sys

from Haver import _HaverPkgError, _HaverPkgWarning

LEN_NAME    = 10
LEN_DTYP    = 8
LEN_DEF     = 82
LEN_GROUP   = 4
LEN_SOURCE  = 6
LEN_GEO     = 8
LEN_SSRC    = 10
LEN_LSRC    = 70

def cversion():
    loaddll()
    hpdll.c_haverCVersion.argtypes = (ct.POINTER(ct.c_int),)
    hpdll.c_haverCVersion.restype  = None
    retval = ct.pointer(ct.c_int())
    hpdll.c_haverCVersion(retval)
    return retval.contents

def loaddll():
    
    global hpdll
    try:
        a = hpdll._handle
    except:
        arch_bit = platform.architecture()[0][0:2]
        dllpath= os.path.dirname(__file__)
        try:
            cwd = os.getcwd()
            os.chdir(dllpath)
            hpdll = ct.WinDLL('Haverp' + arch_bit + '.dll')
        except:
            try:
                sys.path.append(dllpath)
                hpdll = ct.WinDLL('Haverp' + arch_bit + '.dll')
            except:
                raise _HaverPkgError('(API:unableToLoadDLL) Loading of Haver API DLL failed.')
            finally:
                sys.path.remove(dllpath)
        finally:
            os.chdir(cwd)

def deldll():
# needed for testing only

    global hpdll

    try:
        ct.windll.kernel32.FreeLibrary(hpdll._handle)
    except:
        pass
    
    try:
        del hpdll
    except:
        pass

def _haverdbpath_init(pkgdir):
    
    global dlxdbpath_ , dlxdbpath_restore_

    dlxdbpath_ = ''
    dlxdbpath_restore_ = ''
    
    verbose(0)
    try:
        path('saved')
    except:
        pass
    
    if path()=='':  # if True, displays 'Haver path not set' under verbose=1
        try:
            path('auto')
        except:
            pass
    verbose(1)

    
def path(vset=None, save=False):
    """
    .. rubric:: Description
    
    Set, query, and save the path to Haver databases.
    A correct path setting is a prerequisite for data and metadata queries
    run by :ref:`Haver_data` and :ref:`Haver_metadata`.

    Note that ``Haver.path()`` is in no way related to the Python module search path.

    .. rubric:: Syntax
    
    ::
        
      P = Haver.path()
      Haver.path(vset)
      Haver.path(*keyword*)
      Haver.path(save=True)
    
    
    Arguments
    ^^^^^^^^^
    
    vset : str
        Specifies the directory where Haver databases reside.
    save : bool
        Save current path setting to file.
    
    Returns
    ^^^^^^^
    
    str
        When no argument is supplied,
        a str that holds the current setting of the database
        path. If no path is set, an empty str is returned.
    
    Notes
    ^^^^^
    
    .. rubric:: (Syntax Detail)
    
    ``Haver.path()`` returns the current path setting.
    
    ``Haver.path(vset)`` sets the database path to *vset*. *vset* must be
    supplied as an absolute file path.
    If the supplied database path does not exist, an error occurs.
    If the supplied database path does not contain any Haver Analytics databases, a warning is issued.
    
    ``Haver.path(*keyword*)`` takes different actions. *keyword* can be one of
    'auto', 'examples', 'restore', and 'saved', or any abbreviation thereof.
    
    * 'auto' tries to automatically detect
      the correct database path if it is unknown to the user.
      In some instances this may not work, depending on the Python configuration
      and the DLX configuration of your machine.
    * 'examples' sets
      the database path to the example DLX databases that come with the Haver
      package. Before doing so, ``Haver.path()`` will store the existing setting.
      You can re-enable this setting by issuing ``Haver.path('restore')``.
    * 'restore' restores the database path setting that was
      in place when ``Haver.path('examples')`` was invoked.
    * 'saved' sets the path according to a previously saved state.
    
    ``Haver.path(save=True)`` saves the current path setting to the Haver
    package settings file. This setting gets automatically restored upon
    import of the Haver package, or when reloading the Haver package.
    Note: Saving the Haver path affects all users that access this 
    particular package installation.
    
    .. rubric:: (Package Import)
      
    When the Haver package is imported (or reloaded via :py:mod:`importlib`), it
    first tries to restore the database path setting
    from the last session. If this is not successful, it tries
    to detect the correct setting from the DLX
    setup of your machine. If neither of these attempts are successful
    you have to set the database path manually.
    
    """

    global dlxdbpath_ , dlxdbpath_restore_

    settings_file = os.path.join(os.path.dirname(__file__), 'settings.pkl')
    def Haver_path_getsettings():
        Haver_settings = dict()
        try:
            with open(settings_file, 'rb') as input:
                Haver_settings = pickle.load(input)
        except:
            pass
        return Haver_settings

    def Haver_path_savesettings():
    # settings can only be saved if vset=None
        Haver_settings = Haver_path_getsettings()
        Haver_settings['dbpath'] = dlxdbpath_;
        try:
            with open(settings_file, 'wb') as output:
                pickle.dump(Haver_settings, output, -1)
        except:
            Haveraux.warn('(path:unableToSavePath) '
                    'Path has not been saved.');

    if type(save)!=bool:
        raise _HaverPkgError('(inputargs:invArg) Argument "save" incorrectly specified.')
    
    if vset is None:
        if save==True:
            if len(dlxdbpath_restore_)>0:
                raise _HaverPkgError('(inputargs:unableToSavePath) Restore path before saving.')
            Haver_path_savesettings()
            return

        if dlxdbpath_=="":
            if verbose():
                print('Haver path not set.')
        return dlxdbpath_
    else:
        if save==True:
            raise _HaverPkgError('(inputargs:invArgComb) save=True not allowed in this context.')

    if type(vset)!=str:
        raise _HaverPkgError('(inputargs:invArg) Argument "vset" incorrectly specified.')
    
    if vset=='':
        dlxdbpath_ = ''
        return
    
    vset = vset.strip()
    
    [jnkpath, jnkfile] = os.path.split(vset);
    
    if jnkpath=='' and jnkfile==vset:
        vset = vset.lower()
        try:
            vset = Haveraux.abbrevMatch(vset, {'auto', 'examples', 'restore', 'saved'});
        except:
            raise _HaverPkgError('(inputargs:invArgValue) Input argument must either be an absolute path '
                                'or one of ''auto'', ''examples'', ''restore'', or ''saved''.')
        if vset=='auto':
            dbpath = os.environ.get('DLXDB')
            if dbpath is None:
                Haveraux.warn('(path:auto) Automatic detection of the database path failed.\n'
                             'Haver path setting remains unchanged.')
                return
            dbpath = os.path.normpath(os.path.split(dbpath)[0]) + '\\'
                 # e.g. if DLXDB='c:/dlx/data/g10' => dbpath is 'c:\\dlx\\data\\'
            dlxdbpath_ = dbpath
            # print('Using DLXDB environment variable to set the Haver path.')
        elif vset=='examples':
            example_path = os.path.normpath(os.path.split(Haveraux.__file__)[0]+ r'\\dat')
            if not os.path.isdir(example_path):
                raise _HaverPkgError('(path:unableToSetPath) Could not determine path to example databases.')

            # save current dlxdbpath_ to dlxdbpath_restore_,
            #   if not already the path to the example databases
            if 'dlxdbpath_'=='':
                Haveraux.warn('(path:restore) dlxdbpath_ variable not set.'
                             'Haver.path("restore") will not work.')
            else:
                if dlxdbpath_.lower()!=example_path.lower():
                    dlxdbpath_restore_ = dlxdbpath_
            dlxdbpath_ = example_path
            dbpath = example_path; # var 'dbpath' is needed later to check for existence of Haver databases
        elif vset=='restore':
            if dlxdbpath_restore_=='':
                Haveraux.warn('(path:restore) Nothing to restore.')
                return
            else:
                dbpath = dlxdbpath_restore_
                dlxdbpath_ = dbpath
                dlxdbpath_restore_ = ''
        elif vset=='saved':
            Haver_settings = Haver_path_getsettings()
            try:
                dbpath = Haver_settings['dbpath']
            except:
                raise _HaverPkgError('(path:unableToSetPath) Unable to retrieve saved path.')
            if dbpath=='':
                if verbose():
                    print('Haver path had not been saved.')
                return
            dlxdbpath_ = dbpath
            dlxdbpath_restore_ = ''
    else: # manual assignment
        if len(vset)>500:
            raise _HaverPkgError('(inputargs:invArg) Database path may not exceed 500 characters.')
        dbpath = os.path.normpath(vset)
        if dbpath!=os.path.abspath(dbpath):
            raise _HaverPkgError('(path:unableToSetPath) Path supplied is not an abolute path.')
        if not os.path.isdir(dbpath):
            raise _HaverPkgError('(path:unableToSetPath) Folder does not exist.')
        dlxdbpath_ = dbpath
        if 'dlxdbpath_restore_'!='':
            dlxdbpath_restore_ = ''

    if len(glob.glob(dbpath + '\\*.dat'))==0:
        Haveraux.warn('(path:noDatabases) No Haver database files found in new database folder.')

# -------------- Haver.metadata() and related ---------------------------------

def metadata(codes=None, database=None, decode=True):
    """
    .. rubric:: Description
    
    ``Haver.metadata()`` queries metadata information on time series contained
    in Haver Analytics databases. The information is returned in a 
    pandas DataFrame.

    This help entry assumes that you are familiar with the Haver Python Reference
    Section :ref:`Introduction_to_the_Haver_Package_for_Python`.
    
    .. rubric:: Syntax
    
    ::
    
      Haver.metadata(codes)
      Haver.metadata(codes, database)
      Haver.metadata(codes, database, [...])
      Haver.metadata(None , database)
      Haver.metadata(None , database, [...])

      
    Arguments
    ^^^^^^^^^
    codes    : str or tuple of str or list of str
        codes is typically a list of str, or it is an object that fulfills the
        conditions of ``Haver.hasfullcodes()``. The elements of the list
        (tuple) can be regular series codes or additionally supply the database
        where the code resides, in which case they must be specified in
        *database:seriescode* format. Valid examples are 'gdp' and 'usecon:gdp'.
        
        The only difference of usage of the codes argument in comparison to
        ``Haver.metadata()`` is that it is IS optional here (see section
        'Details' below). A single series code can also be supplied as str.
        
    database : str or list or tuple of str with one element
        This argument is optional and specifies a default Haver database
        (excluding the path to the database, and excluding any file extension).
        If this argument is omitted, all elements of codes must be
        in *database:seriescode* format. Otherwise the function errors out.
        
    decode : bool
        This argument is rarely used. By default ``decode is`` ``True``, i.e.
        metadata information that is numerically encoded will be translated to
        meaningful character strings. For example, internally the aggregation
        type 'AVG' (average) is encoded as '1', and the default ``decode`` value
        of ``True`` will re-translate this into 'AVG'.


    Returns
    ^^^^^^^
    pandas.core.frame.DataFrame
        The return value of ``Haver.metadata()`` is a pandas DataFrame object. In the context of the 
        Haver package, this is refered to as a :ref:`Haver_Meta_DataFrame`.
    
    Haver ErrorReport dictionary
        In the case of invalid series code and/or database specifications, a :ref:`Haver_ErrorReport_dictionary`
        is returned.

    
    Notes
    ^^^^^
    
    .. rubric:: (Syntax Detail)
    
    Argument ``codes`` may be omitted if the argument ``database`` is supplied, in which case
    the function interprets the request as referring to all series codes
    contained in the database specified.
    Note that this is not possible with ``Haver.data()``.
    
    There are three possible combinations of using arguments ``codes`` and ``database``:
    
    1. only supply ``codes`` . In this case all elements of ``codes`` have to be in *database:seriescode* format.
    2. only supply ``database`` . This will retrieve metadata for all series contained in the database specified.
    3. supply both ``codes`` and ``database`` . Metadata for all elements of ``codes`` are queried. If
       an element of ``codes`` is not in *database:seriescode* format, the value of ``database`` will
       serve as the default database.
    
    The order of series records within the returned object corresponds to the order of
    series in the input argument ``codes``.
    
    As is generally the case with Haver functions, (str) values of arguments supplied
    are not case-sensitive.
    
    The Haver Python Reference provides much more detail on ``Haver.metadata()``, including examples.
    """
    dbpath = path()
    if dbpath=='':
        raise _HaverPkgError('(path:notSet) You must first define a database path with "Haver.path()".')
    
    loaddll()
    missing_codes    = (codes    is None)
    missing_database = (database is None)
    missing_decode   = (decode   is None)

    if missing_codes and missing_database:
        raise _HaverPkgError('(inputargs:invNumberOfArgs) You must supply at least one of the ' + 
                         'arguments "codes" or "database".')

    # ARGUMENT CHECKS
    wrongarg = None
    if type(codes)==tuple:
        codes = list(codes)

    if not missing_codes and \
       not (type(codes)==str and len(codes)>0 ) and \
       not (type(codes)==list and any([x for x in map(len, codes)])) and \
       not isinstance(codes, pd.DataFrame):
        wrongarg = 'codes'
    if wrongarg is None and not missing_database:
         if isinstance(database, (list, tuple)):
             if len(database)!=1:
                 wrongarg = 'database'
             else:
                 database = database[0]
         if wrongarg is not None or not (type(database)==str and len(database)>0):
             wrongarg = 'database'
    if wrongarg is None and not missing_decode and \
         ((type(decode)!=bool) or \
          (type(decode)==int and decode not in [0,1])):
        wrongarg = 'decode'

    if wrongarg is not None:
        raise _HaverPkgError('(inputargs:invArg) Argument ' + wrongarg + ' incorrectly specified.')

    if missing_decode:
        decode = True
    if not missing_codes:
        if type(codes)==str:
            codes = [codes]
        if type(codes)==list:
            codes = [x for x in map(str.strip, codes)]
            if not (all([x for x in map(len, codes)])):
                raise _HaverPkgError('(inputargs:invArgValue) Argument "codes" contains zero-length strings.')
            if not Haveraux.stringCheck(codes, ':'):
                raise _HaverPkgError('(inputargs:invArgValue) Elements of argument "codes" may only contain alphanumeric characters and a colon.')
        else: # input could be Meta-DataFrame
            if not Haveraux.hasfullcodes(codes):
                raise _HaverPkgError('(inputargs:invArgValue) Cannot deduce code and database from argument "codes".')

    if not missing_database:
        if not Haveraux.stringCheck(database, ''):
            raise _HaverPkgError('(inputargs:invArgValue) Value for argument "database" contains invalid characters.')

    # ARGUMENT PROCESSING
    if not missing_codes:               # query custom code list
        if isinstance(codes, pd.core.frame.DataFrame):
            if not missing_database:
                Haveraux.warn('(inputargs:argIgnored) Argument "codes" has full codes specifications. '
                             'Ignoring argument "database".')
            fullcodes = [d+':'+c for (c,d) in zip(list(codes['code']), list(codes['database']))]
        else:
            fullcodes = codes
            # if possible fill in database from default where missing
            if not missing_database:
                fullcodes = [[x, database+':'+x][x.find(':')<0] for x in codes]
        fullcodes = [x for x in map(str.lower, fullcodes)]

        # check for duplicate full codes
        uniqvec = Haveraux.uniqOrder(fullcodes)
            # fullcodes should remain in order of occurrence
        ndups = len(fullcodes)-len(uniqvec)
        if ndups:
            fullcodes = uniqvec
            Haveraux.warn('(metadataquery:codesRemoved) Removed ' + str(ndups)
                          + ' duplicate "database:seriescode" specification(s).')
        numcodes = len(fullcodes)
        try:
            # codes, databases = [x.split(':') for x in fullcodes]
            codes = []
            databases = []
            for x in fullcodes:
                cursplit = x.split(':')
                assert(len(cursplit)==2)
                codes.append(cursplit[1])
                databases.append(cursplit[0])
        except:
            raise _HaverPkgError('(inputargs:invArgValue) Cannot deduce code and database from some input tokens.')

        # check for duplicate simple codes
        uniqset = set(codes)
        ndups = len(codes)-len(uniqset)
        if ndups:
            Haveraux.warn('(metadataquery:codeDuplicates) Found ' + str(ndups) + ' duplicate(s) of series codes.')
        udblist = Haveraux.uniqOrder(databases)
        pdatabases = [os.path.join(dbpath, x) for x in databases]  # 'p': path
        updblist   = [os.path.join(dbpath, x) for x in udblist]

        isok = checkcodes(codes, pdatabases, updblist)
        if type(isok)==dict:
            Haveraux.warn('(metadataquery:haverErrorReport) Query failed. Returning Haver ErrorReport dictionary.')
            return isok

        hmd = api_haverGetAllInfo(codes, pdatabases)
    else:                                # query full db
        database   = database.lower()
        pdatabase  = os.path.join(dbpath, database)
        numcodes   = api_haverNumCodes(pdatabase)
        codes      = api_haverGetCodes(pdatabase, numcodes)
        pdatabases = [pdatabase] * numcodes
        hmd        = api_haverGetAllInfo(codes, pdatabases)
        # databases  = [database] * numcodes
    if decode==True:
        Haveraux.decodeMetadata(hmd)
        
    haverinfo = {}
    haverinfo['description'] = 'Haver Analytics metadata query (' + \
                      datetime.now().strftime('%Y-%b-%d %H:%M:%S') + ')'

    haverinfo['vardescription'] = [
        'Haver Database Name',
        'Series Code',
        'Start Date',
        'End Date',
        'Frequency',
        'Series Description',
        'Number of Time Periods in Range [Start Date , End Date]',
        'Date/Time Last Modified',
        'Magnitude',
        'Decimal Precision',
        'Calculation Allowed in DLX Software; 0= %, 1= % Calc not Allowed',
        'Aggregation Type',
        'Data Type',
        'Update Group',
        'Primary Geography Code',
        'Secondary Geography Code',
        'Short Source Description',
        'Long Source Description']

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        hmd.haverinfo = haverinfo
        
    return hmd

# -------------- Haver.data() related -----------------------------------------
    
def data(codes, database=None, startdate=None, enddate=None, frequency=None,
         aggmode='strict', eop=True, dates=False, uselimits=True):
    """
    
    .. rubric:: Description
    
    ``Haver.data()`` queries time series data contained in Haver Analytics databases. The
    data are returned as a pandas DataFrame.
    
    ``Haver.hasfullcodes()`` is a small helper function.
    
    This help entry assumes that you are familiar with the Haver Python Reference
    Section :ref:`Introduction_to_the_Haver_Package_for_Python`.
    
    
    .. rubric:: Syntax
    
    ::
    
      hd = Haver.data(codes)
      hd = Haver.data(codes, database)
      hd = Haver.data(codes, database, [...])
      hd = Haver.data(codes, None    , [...])
    
      Haver.hasfullcodes(x)
    
    
    Arguments
    ^^^^^^^^^
    
    codes       : str or tuple of str or list of str
        codes is typically a list of str, or it is an object that
        fulfills the conditions of ``Haver.hasfullcodes()``.
        If a list of str is supplied, the elements can be regular series
        codes or additionally supply the database where the code resides, in
        which case the elements must be specified in *database:seriescode* format.
        Examples of list of str elements are 'gdp' and 'usecon:gdp'.
        
        Haver series codes may also be supplied through an object that passes
        ``Haver.hasfullcodes()``. The only difference of usage of the codes
        argument in comparison to ``Haver.metadata()`` is that it is NOT optional here
        (see section 'Notes' below). A single series code can also be supplied
        as str.
        
    database    : str or list or tuple of str with one element
        This argument is optional and specifies a default Haver database
        (excluding the path to the database, and excluding any file extension).
        If this argument is omitted, all elements of ``codes`` must be in
        *database:seriescode* format. Otherwise the function errors out.
        
    startdate   : str or datetime.date
        Specifies the starting date of the query. If is is specified as 
        str, it is converted to a datetime.date object using the input format
        yyyy-MM-dd, e.g. ('2005-12-31). Even though ``startdate`` is supplied as a
        datetime.date object (or date string), it is interpreted within the context
        of the frequency of the DataFrame. This is an important point.
        See section :ref:`Specifying_Query_Starting_and_Ending_Periods`
        in the Haver Python Reference for details.
        
    enddate     : str or datetime.date
        Specifies the ending date of the query. Analogous comments as for
        ``startdate`` apply.
        
    frequency   : str or list or tuple of str with one element
        Specifies the target frequency of the query. One of 'daily', 'weekly',
        'monthly', 'quarterly', 'annual', or 'yearly', or any abbreviation
        thereof, down to a single character.
        
    aggmode     : str or list or tuple of str with one element
        The aggregation mode of the query. One of 'strict', 'relaxed', or
        'force', or any abbreviation therof. See section
        :ref:`Temporal_Aggregation_Modes`
        in the Haver Python Reference for details. Default: 'strict'.
        
    dates       : bool
        Determines whether time
        periods are shown as dates (e.g. '2000-03-31' instead of '2000Q1').
        Data with frequencies other than weekly are displayed with respect
        to time periods. Weekly data are shown as dates. The date shown
        for weekly data corresponds to the anchor weekday of the series or 
        DataFrame. See :ref:`Daily_and_Weekly_Queries`
        in the Haver Python Reference for more details.
        Default: ``True`` for weekly DataFrames, ``False`` for other frequencies.
        
    eop         : bool
        Determines whether dates
        are recorded beginning-of-period or end-of-period. Only relevant if
        ``dates=True``. Default: ``True``.

    uselimits   : bool
        If ``False``, ``Haver.data()`` ignores settings regarding query limits.
        Default: ``True``.

    
    Returns
    ^^^^^^^
    
    pandas.core.frame.DataFrame
        The return value of ``Haver.data()`` is a pandas DataFrame object. In the context of the 
        Haver Package, this is referred to as a Haver DataFrame.
        
        In the case of invalid series code and/or database specifications, a Haver ErrorReport dictionary
        is returned.
        
        ``Haver.hasfullcodes()`` returns a ``bool``.
    
    
    Notes
    ^^^^^
    
    .. rubric:: (Syntax Detail)
    
    Both ``Haver.data()`` and ``Haver.metadata()`` take arguments ``codes`` and ``database``. They allow
    you to conveniently specify Haver Analytics series codes. Usage of these arguments
    in the two functions is very similar, with just one exception: If the argument ``codes``
    is omitted in ``Haver.metadata()``, the function interprets the request as referring
    to all series codes contained in the database specified.
    In ``Haver.data()``, such an interpretation is not made, and
    consequently the argument ``codes`` is not optional here.
    
    The order of series records within the returned object corresponds to the order of
    series in the input argument codes.
    
    As is generally the case with Haver functions,
    (str) values of arguments supplied are not case-sensitive.
    
    An object that passes the test of ``Haver.hasfullcodes()`` can be used as input argument
    ``codes`` instead of a list (tuple) of str. ``Haver.hasfullcodes()`` returns a logical ``True``
    if an object satisfies the following conditions:
    
    * it is a pandas DataFrame
    * whose first two columns are named 'database' and 'code'
    * and have admissible data types, as described above under 'Input Arguments'
    * with no empty entries
    * and have only alphanumeric entries
    * and have at least one entry (the DataFrame has at least one row).
    
    See the ``Haver.data()`` 'Examples' section in the Haver Python Reference for more information on this technique.
    
    The Haver Python Reference provides much more detail on ``Haver.data()``, including examples.
    """

    # numeric frequency symbols (complicated mainly b/c of weekly freq handling)
    # dlxfreq_in   : one of 1000, 60, 57   , 40, 30, 10    user input
    #                                                       weekly is encoded as 57
    #                                                       but may be temporarily set to 51 in order for some conditional statements to be correct
    # dlxfreq_md   : one of       60, 57   , 40, 30, 10    determined based on HaverMetaData object that is examined before API calls
    #                                                       weekly is encoded as 57
    #                                                       but may be temporarily set to 51 in order for some conditional statements to be correct
    # dlxfreq_out  : one of       60, 57-51, 40, 30, 10    the return value of API call c_haverObsNum now weekly is set accurately to the release day freq of the data set
    
    dbpath = path()
    if dbpath=='':
        raise _HaverPkgError('(path:notSet) You must first define a database path with "Haver.path()".')
 
    missing_database  = (database  is None)
    missing_start     = (startdate is None)
    missing_end       = (enddate   is None)
    missing_frequency = (frequency is None)
 
    wrongarg = None

    if type(codes)==tuple:
        codes = list(codes)
    if type(codes)==str:
        codes = [codes]
    if type(codes)==list:
        for x in codes:
            if type(x)!=str or len(x)==0:
                wrongarg = 'codes'
                break
    if not isinstance(codes, (list, pd.DataFrame)):
        wrongarg = 'codes'

    if wrongarg is None and not missing_database and \
         not (type(database)==str and len(database)>0) and \
         not (isinstance(database, (list, tuple)) and len(database)==1):
        wrongarg = 'database'
    if wrongarg is None and not missing_start and \
         not (isinstance(startdate, (str,date))):
        wrongarg = 'startdate'
    if wrongarg is None and not missing_end and \
         not (isinstance(enddate, (str,date))):
        wrongarg = 'enddate'
    if wrongarg is None and not missing_frequency and \
         not (type(frequency)==str):
        wrongarg = 'frequency'
    if wrongarg is None and not (type(aggmode)==str):
        wrongarg = 'aggmode'
    if wrongarg is None and not (type(dates)==bool):
        wrongarg = 'dates'
    if wrongarg is None and not (type(eop)==bool):
        wrongarg = 'eop'
    if wrongarg is None and not (type(uselimits)==bool):
        wrongarg = 'uselimits'
        
    if wrongarg is not None:
        raise _HaverPkgError('(inputargs:invArg) Argument ' + wrongarg + ' incorrectly specified.')

    if not missing_start and not isinstance(startdate, date):
        try:
            startdate = datetime.strptime(str(startdate), '%Y-%m-%d').date()
        except:
            raise _HaverPkgError('(invDate) Could not create startdate date instance.')
    if not missing_end and not isinstance(enddate, date):
        try:
            enddate = datetime.strptime(str(enddate), '%Y-%m-%d').date()
        except:
            raise _HaverPkgError('(invDate) Could not create enddate date instance.')
 
    if not missing_frequency:
        frequency = frequency.lower()
        try:
            frequency = Haveraux.abbrevMatch(frequency, Haveraux.const_freq_str6)
        except:
            raise _HaverPkgError('(inputargs:invArgValue) Argument "frequency" incorrectly specified.')

    if aggmode!='strict':
        try:
            aggmode = Haveraux.abbrevMatch(aggmode, Haveraux.const_aggmode_str)
        except:
            raise _HaverPkgError('(inputargs:invArgValue) Argument "aggmode" incorrectly specified.')
    
    if type(codes)==str:
            codes = [codes]
    if not missing_frequency:
        if frequency=='yearly':
            frequency = 'annual'
        dlxfreq_in = Haveraux.freqNumeric(frequency[0], None , 'dlxfreq')
        if dlxfreq_in == 55:
            dlxfreq_in = 57  # 'w'=57 can be set correct release day is set by c_haverObsNum
             # must not set it to any of 51:56 since the message about aggregation
             # as well as the noaggdf depend on it
    else:
        dlxfreq_in = 1000
 
    if missing_start:
        ymdstart = -1
    else:
        start = startdate
        if type(start)==str:
            start = datetime.strptime(start, '%Y-%m-%d').date()
        if start < datetime.strptime('01jan1900', '%d%b%Y').date():
            raise _HaverPkgError('(inputargs:invArgValue) Start date must be within years 1900-2099).')
        ymdstart = Haveraux.dtToYmd(start)
    if missing_end:
        ymdend = -1
    else:
        end = enddate
        if type(end)==str:
            end = datetime.strptime(end, '%Y-%m-%d').date()
        if end > datetime.strptime('31dec2099', '%d%b%Y').date():
            raise _HaverPkgError('(inputargs:invArgValue) End date must be within years 1900-2099).')
        ymdend = Haveraux.dtToYmd(end)
    if not missing_start and not missing_end:
        if start>end:
            raise _HaverPkgError('(inputargs:invArgValue) Start date is after end date.')
 
    aggmode = aggmode.lower()
    aggmode_num = Haveraux.const_map_aggmode_s2n[aggmode]
 
    # API CALLS: METADATA
    if missing_database:
        md = metadata(codes, None    , decode=False)
    else:
        md = metadata(codes, database, decode=False)
    
    if type(md)==dict:  # Haver ErrorReport dictionary
        # do not issue warning: warning from haver.metadata has been displayed already
        return md

    mdinfo = md.haverinfo # attribute haverinfo will get lost during copy operations
 
    numcodes = md.shape[0]
    if uselimits == True:

        lim = limits()
        limit_numcodes      = lim[0]
        limit_numdatapoints = lim[1]
        if (numcodes > limit_numcodes):
            raise _HaverPkgError('(dataquery:limitExceeded) ' + str(numcodes) + 
            ' codes requested, but limit "numcodes" is set to '
            + str(limit_numcodes)  + '.')

    # DROP SERIES
    numnoobs = 0
    numnoagg = 0
    numnodag = 0
    noobsfcd = []
    noaggfcd = []
    nodagfcd = []

    # DETECT SERIES WITH NO DATA POINTS
    noobsdf = md[md.numobs==0][['code', 'database']]
    if len(noobsdf)>0:
        numnoobs = noobsdf.shape[0]
        noobsfcd = (noobsdf.database + ':' + noobsdf.code).tolist()
        md = md.drop(noobsdf.index.tolist())
 
    # REMOVE SERIES THAT CANNOT BE AGGREGATED, IF NECESSARY  DETERMINATION OF DATA SET FREQ
    if len(md)>0:
        freqvec = set(md.frequency.unique())
    
        if dlxfreq_in < 1000:
            dlxfreq_tmp = dlxfreq_in
            if dlxfreq_in == 57:
                dlxfreq_tmp = 51 # necessary for next statement to be correct
            if max(freqvec) < dlxfreq_tmp:
                raise _HaverPkgError('(dataquery:noDataPoints) Series not available in the requested frequency.')
                      # if series are of lower freq than requested by user, they get dropped
                      # error out if all series would get dropped
            dlxfreq_md = dlxfreq_in  # 'md': metadata
        else:
            dlxfreq_md = min(freqvec)
        if dlxfreq_md>=51 and dlxfreq_md<=57:
            dlxfreq_md = 57 # need to assign a value that I can reliably use in conditions
                             # may be temporarily re-set to 51
                             # note: output data freq for weekly 51-57 will NOT be
                             #       determined by the lowest freq  of the series
                             #       but intstead by be the release day of the first series
        if len(set(md.aggtype.unique()).intersection(set([0,9])))>0:
            noaggdf = md.loc[(md.aggtype.isin([0,9])) & (md.frequency>dlxfreq_md)]
            if len(noaggdf)>0:
                numnoagg = noaggdf.shape[0]
                noaggfcd = (noaggdf.database + ':' + noaggdf.code).tolist()
                md = md.drop(noaggdf.index.tolist())

 
    # REMOVE SERIES THAT CANNOT BE >DIS<-AGGREGATED, IF NECESSARY
    if len(md)>0:
        dlxfreq_tmp = dlxfreq_in
        if dlxfreq_in == 57:
            dlxfreq_tmp = 51 # necessary for next statement to be correct
        if dlxfreq_in<1000:
            nodagdf = md[(md.frequency < dlxfreq_tmp)]
                 # 'dag': DisAGgregation
                 # if arg 'freq' is not specified, the API chooses the highest possible freq
                 # for all series, so len(nodagdf)=0
            if len(nodagdf)>0:
                numnodag = nodagdf.shape[0]
                nodagfcd = (nodagdf.database + ':' + nodagdf.code).tolist()
                md = md.drop(nodagdf.index.tolist())

    if numnoagg>0 or numnodag>0 or numnoobs>0:
        if verbose():
            print('  Dropping codes from query:')
            if numnoagg>0:
                print('    temporal aggregation not allowed     : ' + str(numnoagg) + ' code(s)')
            if numnodag>0:
                print('    temporal disaggregation not possible : ' + str(numnodag) + ' code(s)')
            if numnoobs>0:
                print('    no observations                      : ' + str(numnoobs) + ' code(s)')
 
    if len(md) == 0:
        raise _HaverPkgError('(dataquery:noDataPoints) All codes have been dropped.')
 
    codes      = list(md.code)
    numcodes   = len(codes)
    pdatabases = (dbpath + r'\\' + md.database).tolist()
    updblist   = Haveraux.uniqOrder(pdatabases)
    numudbs    = len(updblist)
    
    Haveraux.decodeMetadata(md)

    # API CALL: OBSNUM AND FREQUENCY
    obsinfo = api_haverObsNum(codes, pdatabases, updblist, numcodes, ymdstart, ymdend, dlxfreq_in)

    dlxstart    = obsinfo['dlxstart']
    dlxend      = obsinfo['dlxend']
    dlxfreq_out = obsinfo['dlxfreq_out']
    obsnum      = obsinfo['obsnum']

    if dlxfreq_in < 1000:
        if dlxfreq_md==57:
            if dlxfreq_out<51 or dlxfreq_out>57:
                raise _HaverPkgError('(API:PythonCMismatch) Python and C code frequency mismatch.')
        else:
            if dlxfreq_out!=dlxfreq_md:
                raise _HaverPkgError('(API:PythonCMismatch) Python and C code frequency mismatch.')

    freqChar     = Haveraux.freqChar( Haveraux.freqNumeric(dlxfreq_out, 'dlxfreq', 'trufreq'), 'trufreq')
    freqString   = Haveraux.freqString(freqChar)

    if obsnum == -1:
        if not missing_start and (dlxend < dlxstart):
            raise _HaverPkgError('(dataquery:noDataPoints) Value of argument "start" later than end of data series.')
        if not missing_end   and (dlxend < dlxstart):
            raise _HaverPkgError('(dataquery:noDataPoints) Value of argument "end" before beginning of data series.')
        raise _HaverPkgError('(dataquery:noTimeSpan) Could not determine time span of observations.')

    if uselimits==True:
        if obsnum*numcodes > limit_numdatapoints:
            raise _HaverPkgError('(dataquery:limitExceeded) ' + str(obsnum*numcodes) + ' data points requested, '
                             'but limit "numdatapoints" is set to ' +
                             str(limit_numdatapoints) + '.')

    # API CALL: DATA
    aggmodeold = api_dlxGetAggregation()
 
    if aggmode!=aggmodeold:
        api_dlxSetAggregation(aggmode)

    rawdata = api_haverGetData(codes, pdatabases, \
           updblist, dlxstart, dlxend, dlxfreq_out, obsnum)

    if aggmode!=aggmodeold:
        api_dlxSetAggregation(aggmodeold)
 
    # API CALL: DATE SEQUENCE
    dateseq = api_haverDateSeq(dlxstart, obsnum, dlxfreq_out) # dateseq is returned as ymddate
    dateseq = Haveraux.ymdToDt(dateseq)   # now Python datetime (eop)
    
    f = freqChar.upper()
    if freqChar=='d':
        f = 'B'  # business daily
    elif freqChar=='w':
        f = Haveraux.const_map_freq_d2p[dlxfreq_out]
    idx = pd.PeriodIndex(data=dateseq, freq=f)
    
    if dates is None:
        dates = False
        if freqChar=='w':
            dates = True
                # For anchor day=Wednesday, pandas displays periods as e.g.
                # 2012-02-23/2012-02-29, with 2012-02-29 being a Wednesday.
                # The default for weekly data is to show dates=True, eop=True.
    
    if dates==True:
        if eop==True:
            idx = idx.to_timestamp(how='end')
        else:
            idx = idx.to_timestamp(how='start')
            
    # prepend DataFrame column names with database names if necessary
    uniqvec = set(codes)
    ndups = numcodes-len(uniqvec)
    kw = keyword.kwlist
    kwcodes = [x for x in kw if x in codes]
    if ndups>0 or len(kwcodes)>0:
        colcodes = list(md.database + '_' + md.code)
    else:
        colcodes = codes

    datadict = {}
    obsnum = rawdata['obsnum']

    for i in range(0,numcodes):
        datadict[colcodes[i]] = rawdata['data'][(i*obsnum):((i+1)*obsnum)]
    
    hd = pd.DataFrame(datadict, index=idx, columns=colcodes)
        # the dict passed has a different order than codes. Arg columns=codes fixes this.
    hd = hd.replace(1e9, np.nan)
    
    md.reset_index(inplace=True, drop=True)  # index may have gaps due to removal of series

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        md.haverinfo = mdinfo
        hd.haverinfo = {}
    
    hd.haverinfo['description']    = 'Haver Analytics data query (' + str(datetime.now()) + ')'
    hd.haverinfo['vardescription'] = list(md.descriptor)
    hd.haverinfo['metadata']       = md
    hd.haverinfo['frequency']      = freqString
    hd.haverinfo['codelists']      = {'noobs': noobsfcd, 'noagg': noaggfcd, 'nodisagg': nodagfcd}
    
    return hd

# -------------- Haver.databases, Haver.limits, Haver.codelists, Haver.verbose --------------

def databases(disp=False):
    """
    .. rubric:: Description
    
    Print or return list of Haver Analytics databases.
    
    ``Haver.databases(disp=True)`` displays a list of Haver Analytics database
    files ('.DAT' extension files) that are accessible under the current
    setting of ``Haver.path()``.
    
    ``dblist = Haver.databases()`` returns the same list of databases in a 
    list. All elements of the list have been
    stripped of the file extension and are in upper case.


    .. rubric:: Syntax
    
    ::
        
      Haver.databases(disp=True)
      dblist = Haver.databases()


    Arguments
    ^^^^^^^^^
    
      disp : bool


    Returns
    ^^^^^^^
    None
        returned by ``Haver.databases(disp=True)``.
    list of str
        returned by ``Haver.databases()``.
        List of Haver Analytics database files found.
        The entries are in upper case and the '.DAT' has been removed.
        The list is build with respect to the current setting of
        ``Haver.path()``.


    Examples
    ^^^^^^^^
    
      >>> Haver.path()
      >>> Haver.path('examples')
    
    Let's look at the example databases that are shipped with the Haver
    package::
    
      Haver.path()
      Haver.path('examples')
      Haver.databases(disp=True)
    
    We can save the database names in a list of str::
    
     ex_dbs = Haver.databases()
     ex_dbs
    
    ::
     
     >>> Haver.path('restore')
    """

    if not isinstance(disp, (bool, int)):
        raise _HaverPkgError('(inputargs:invArg) Argument "disp" incorrectly specified.')

    dbpath = path()
    if dbpath=="" or dbpath is None:
        return None
    
    dblist = glob.glob(path() + "/*.dat")
    numdbs = len(dblist)
    if numdbs>0:
        dblist = [os.path.basename(x).upper().split('.')[0] for x in dblist]

    if disp==True:
        if not verbose():
            return None

        if numdbs==0:
            print('No database files found.')
            return None
        
#        for x in dblist:
#            print(x)
        colw = 18
        numcols = 4
        numlines = math.ceil(numdbs / numcols)

        dblist = [x + ' ' * (colw-len(x)) for x in dblist] # pad w/ blanks to uniform length
        dblist = dblist + [''] * (numlines * numcols - len(dblist))
        cols = [[]] * numcols
        for r in range(numcols):
            beg = (r * numlines)
            end = (r+1)*numlines
            cols[r] = dblist[beg:end]
        for l in range(numlines):
            line = ''
            for c in range(numcols):
                line = line + cols[c][l]
            print(line)

        return None
    else:
        if numdbs==0:
            if verbose():
                print('No database files found.')
                return []
        return dblist

def limits(parameter=None, value=None):
    """
    .. rubric:: Description
    
    Set and get limits for Haver Analytics data queries.
    
    ``Haver.limits()`` handles the settings with regards to the limits of data queries of ``Haver.data()``.
    Note that these limits have no impact on the metadata queries of ``Haver.metadata()``.
    
    Limits on the size of queries are imposed to protect you from unintentionally conducting
    very large queries that are problematic in terms of execution time or memory consumption.
    
    
    .. rubric:: Syntax
    
    ::

      S = Haver.limits()
      Haver.limits('default')
      Haver.limits(parameter, value)
    
    
    Arguments
    ^^^^^^^^^
    
      parameter : str
          one of 'numcodes', 'numdatapoints', or 'default', or any unambiguous abbreviation thereof.
          
          ``parameter='numcodes'`` sets the maximum allowed number of codes in a query to ``value``.
          
          ``parameter='numdatapoints'`` sets the maximum allowed number of data points in a query to ``value``.
          
          ``parameter='default'`` ignores ``value``, if supplied, and restores default
          values for 'numcodes' and 'numdatapoints',
          which are 1,000 and 15,000,000, respectively.
      value : numeric non-negative scalar
          specifies the limit for the 'numcodes' or 'numdatapoints' setting.
    
          
    Returns
    ^^^^^^^
    
      list
          The numbers in the first and second position indicate the limits on the
          number of codes and the number of data points, respectively.
    
    Notes
    ^^^^^
    
    .. rubric:: (Syntax Detail)
    
    The values set by ``Haver.limits()`` are taken into account by ``Haver.data()``. It will issue
    an error if a query is beyond what is allowed by query limits, unless you specify its
    option ``uselimits='False'``.
    
    ``Haver.limits()``, with an empty argument list, returns the current
    settings.
    
    ``Haver.limits('default')`` restores Haver default values.
    
    Any values set by ``Haver.limits()`` will remain in effect until Python is
    restarted. A restart will result in the restoration of default values.
    
    The default values for query limits allow you to conduct queries which are fairly
    sizeable. The default for the maximum number of codes is 5000. The default for the
    maximum number of data points is 15 million, which is a little bit more than a daily
    data set with 1000 time series, covering 50 years of data. Such a data set requires
    more than 100 megabyte of memory, but the memory necessary for performing the retrieval
    is several times as high. Before you increase values for limits, make sure these are tenable
    for your system. 
    """
    
    # ARGUMENT CHECKS
    para = parameter
    missing_para  = para  is None
    missing_value = value is None

    if not missing_para:
        if not isinstance(para, str) or len(para)==0:
            raise _HaverPkgError('(inputargs:invArg) Argument "parameter" incorrectly specified.')
        try:
            para = Haveraux.abbrevMatch(para, ['default', 'numcodes', 'numdatapoints'])
        except:
            raise _HaverPkgError('(inputargs:invArg) Argument "parameter" incorrectly specified.')
            
    if not missing_value:
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            raise _HaverPkgError('(inputargs:invArg) Argument "value" incorrectly specified.')
        if value<1:
            raise _HaverPkgError('(inputargs:invArgValue) "Value" must be >=1.')

    global dlxnumcodes_ , dlxnumdatapoints_

    try:
        isinstance(dlxnumcodes_, (int, float))
    except:
        dlxnumcodes_      = Haveraux.const_limit_numcodes

    try:
        isinstance(dlxnumdatapoints_, (int, float))
    except:
        dlxnumdatapoints_ = Haveraux.const_limit_numdatapoints
    
    if missing_para and missing_value:
        return [dlxnumcodes_, dlxnumdatapoints_]

    if missing_para:
        raise _HaverPkgError('(inputargs:invNumberOfArgs) Argument "parameter" missing.')
    para = para.lower().strip()
    if missing_value and para!='default':
        raise _HaverPkgError('(inputargs:invArgValue) Argument "parameter" must be either empty or set '
                         'to "default" if argument "value" is not supplied.')

    if para=='default':
        dlxnumcodes_      = Haveraux.const_limit_numcodes
        dlxnumdatapoints_ = Haveraux.const_limit_numdatapoints
        if verbose():
            print('Resetting Haver limits to default values.')
    elif para=='numcodes':
        dlxnumcodes_ = value
        if verbose():
            print('Resetting Haver limit "numcodes".')
    elif para=='numdatapoints':
        dlxnumdatapoints_ = value
        if verbose():
            print('Resetting Haver limit "numdatapoints".')
    else:
        raise _HaverPkgError('(inputargs:invArgValue) Value of argument "parameter" not recognized.')

def codelists(objin):
    """
    .. rubric:: Description
    
    Extract lists of Haver series codes.
    
    ``Haver.codelists()`` extracts lists of Haver series codes from Haver Meta-DataFrames,
    Haver DataFrames, and Haver ErrorReport dictionaries.
    
    These objects contain information on various Haver series code
    lists.  :ref:`Haver_codelists` accesses this information. For the most
    part, this information is related to the section 'When Data Cannot
    Be Retrieved' of :ref:`Haver_data`.
    
    
    .. rubric:: Syntax

    ::
        
      L = Haver.codelists(objin)
    
    
    Arguments
    ^^^^^^^^^
    
      objin : Haver ErrorReport dictionary or Haver DataFrame or Haver Meta-DataFrame
    
    
    Returns
    ^^^^^^^
    
      dict of length 3 or 4
          See the Haver Python Reference for details.
    """

    if type(objin)==dict:  # Haver error report dictionary
        dictkeys = set(objin.keys())
        herkeys  = {'databasepath', 'querydateandtime', 'codelists'}

        if len(dictkeys-herkeys)>0:
            raise _HaverPkgError('(objects:notAHaverErrorReport) '
                  'Unable to retrieve a valid codelist.')
        return objin['codelists']
    # elif isinstance(objin, pd.core.frame.DataFrame):
    elif 'pandas.core.frame.DataFrame' in str(type(objin)):
        if len({'database', 'code'} - set(objin.columns.values))==0: # Meta-DataFrame:
            if not Haveraux.hasfullcodes(objin):
                raise _HaverPkgError('(objects:notAHaverDataFrame) '
                      'Unable to retrieve a valid codelist.')
            return (objin.database + ':' + objin.code).tolist()
        else: # DataFrame:
            try:
                md = objin.haverinfo['metadata']
            except:
                raise _HaverPkgError('(objects:notAHaverDataFrame) '
                      'Unable to retrieve a valid codelist.')
            codesout = (md.database + ':' + md.code).tolist()
            mydict = objin.haverinfo['codelists'].copy()
            if not isinstance(mydict, dict) or \
               len(set(mydict.keys()) - {'noagg', 'nodisagg', 'noobs'})>0:
                    raise _HaverPkgError('(objects:notAHaverDataFrame) '
                          'Unable to retrieve a valid codelist.')

            mydict['codesout'] = codesout
            return mydict

def verbose(vset=None):
    """
    .. rubric:: Description
    
    Set verbose message mode of Haver functions to ``True`` or ``False``.
    
    ``Haver.verbose()`` sets the message display mode of Haver functions
    to be on or off.
    When you set the message display mode to non-verbose, the Haver
    functions will not generate any output if you terminate statements
    with a semi-colon, except for warnings and error messages.
    
    .. rubric:: Syntax
    
    ::
    
      M = Haver.verbose()
      Haver.verbose(vset)
    
    
    Arguments
    ^^^^^^^^^
    
      vset : bool or numeric 0/1
          A numeric 0 (1) or boolean ``False`` (``True``) turn the verbose mode off (on).
    
    
    Returns
    ^^^^^^^
      bool
          A logical False (True) indicates that the verbose mode is off (on).
    

    Notes
    ^^^^^
    
    .. rubric:: (Syntax Detail)
    
    ``M = Haver.verbose()`` returns a bool indicating
    whether the mode of displaying messages is on (True) or off (False).
    
    ``Haver.verbose(vset)`` sets the display mode of messages on or off. ``vset``
    must be a bool or a numeric 0/1 value.
    
    The verbose setting concerns regular messages issued via the ``print()``
    function only. Warnings and error messages are not affected.
    You can handle the display of warnings and errors as usual in Python.
    
    Unless there is a specific reason to set the verbose mode to ``False``, we
    recommend not doing so.
    
    
    Examples
    ^^^^^^^^
    
      >>> Haver.path()
      >>> Haver.path('examples')
    
    We first save the current setting for the verbose mode::
    
      ex_verb = Haver.verbose()
    
    Verbose mode settings affect data queries, among other things::
    
      hmd = Haver.metadata(database='havermqa')  # preparatory statement
      Haver.verbose(1)
      hd  = Haver.data(hmd)
    
      Haver.verbose(0)
      hd  = Haver.data(hmd)
    
    After verbose mode was turned off, we were not notified that two
    series got dropped from the query. ::
    
      Haver.verbose(ex_verb)
    
    ::
    
      >>> Haver.path('restore')
    """

    global dlxverbose_

    if vset is None:
        try:
            if dlxverbose_=="":
                dlxverbose_ = True
        except:
            dlxverbose_ = True
        return dlxverbose_
    else:
        if not((type(vset)==bool) or \
               (isinstance(vset, (int, float)) and vset in [0, 1])):
                    raise _HaverPkgError('(inputargs:invArg) Input argument "set" incorrectly specified.')
        dlxverbose_ = int(vset)
        return None

   
# --------------auxiliary functions (moved here from Haveraux) --------------
    
def checkcodes(codes, pdatabases, updblist):
    """checkcodes(codes, pdatabases, updblist)

    auxiliary def for main Haver package functions:
    for an arbitrary list of full Haver codes, separates codes that can be
      queried from codes that cannot.
    expects two nonempty str vectors of equal length
    returns boolean TRUE (1) if codes are ok and a havererror if they are not

    """
    
    # should be an auxiliary function, but included in module Haver.py to simplify imports and function calls
    
    if type(updblist)==str:
        updblist = [updblist]
    if (not isinstance(codes, (list, tuple)) or
        not isinstance(pdatabases, (list, tuple)) or
        not isinstance(updblist, (list, tuple))):
        raise _HaverPkgError('(Haver.checkcodes) Invalid argument.')

    lcd = len(codes)
    ldb = len(pdatabases)
    if (lcd == 0) or (lcd != ldb):
        raise _HaverPkgError('(Haver.checkcodes) Invalid argument.')

    ncvn = [len(x) for x in codes]
    ncdb = [len(x) for x in pdatabases]
    if (min(ncvn) == 0 or min(ncdb) == 0):
        raise _HaverPkgError('(Haver.checkcodes) Invalid argument.')
        # checks on code string length etc. are omitted to account for
        #   potential future changes

    numudbs  = len(updblist)
    numcodes = lcd

    # indexes for problematic codes:
    nodb_idx = [0 for x in range(0, lcd)]  # db not opened
    novn_idx = nodb_idx[:]                 # code not found
    noif_idx = nodb_idx[:]                 # could not get info:

    # # HAVERCHECKCODES
    checked = api_haverCheckCodes(codes, pdatabases, updblist, numudbs, numcodes)
    
    if checked[0]==0:  # first elem of list is bool for codesOK
        codesOK, nodb_idx, novn_idx, noif_idx = checked[:]

        nodb_idx = [x-1 for x in nodb_idx if x!=0]
        novn_idx = [x-1 for x in novn_idx if x!=0]
        noif_idx = [x-1 for x in noif_idx if x!=0]
            # were initialized to length lcd, get rid of zero elements
            #   get returned as vectors that already contain index values of
            #   problematic codes, but are of length numcodes
            #   deduct one for base zero indexing

        bad_idx  = set(nodb_idx + novn_idx + noif_idx)
        good_idx = {x for x in range(0,numcodes)} - bad_idx

        databases = list(map(os.path.basename, pdatabases))
        invcodes = []
        for (d, c) in zip(databases, codes):
            invcodes.append(d + ':' + c)
        codesfound     = [x for (i,x) in enumerate(invcodes) if i not in bad_idx]
        databaseaccess = [x for (i,x) in enumerate(invcodes) if i     in nodb_idx]
        codesnotfound  = [x for (i,x) in enumerate(invcodes) if i     in novn_idx]
        metadataaccess = [x for (i,x) in enumerate(invcodes) if i     in noif_idx]

        havererror = {}
        havererror['databasepath']     = os.path.dirname(pdatabases[0])
        havererror['querydateandtime'] = \
                   datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        havererror['codelists'] = {'codesfound':codesfound, 
                                   'databaseaccess':databaseaccess,
                                   'codesnotfound':codesnotfound,
                                   'metadataaccess':metadataaccess}
        return havererror
    else:
        return 1

# -------------- API call related ---------------------------------------------

def api_haverNumCodes(pdatabase):
    if not type(pdatabase)==str:
        raise _HaverPkgError('(API:haverNumCodes) Invalid argument.')
    
    hpdll.c_haverNumCodes.argtypes = (ct.c_char_p, ct.POINTER(ct.c_int))
    hpdll.c_haverNumCodes.restype  = ct.c_int
    
    perrnum   = ct.pointer(ct.c_int(0))
    
    numcodes = hpdll.c_haverNumCodes(ct.c_char_p(pdatabase.encode()), perrnum)
        # .encode(): convert pdatabase from string to bytes
    if perrnum.contents.value!=0:
        Haveraux.api_raiseError(perrnum.contents.value)

    return numcodes

def api_haverGetCodes(pdatabase, numcodes):
    if pdatabase is None or numcodes is None:
        raise _HaverPkgError('(API:haverGetCodes) Argument missing.')
    if (type(pdatabase)!=str or not isinstance(numcodes, (int, float))):
        raise _HaverPkgError('(API:haverGetCodes) Invalid argument.')

    string_buffers = [ct.create_string_buffer(LEN_NAME) for i in range(numcodes)]
    codes = (ct.c_char_p * numcodes)(*map(ct.addressof, string_buffers))
    
    hpdll.c_haverGetCodes.argtypes = (ct.POINTER(ct.c_char_p), ct.c_char_p, ct.c_int, ct.POINTER(ct.c_int))
    hpdll.c_haverGetCodes.restype  = None
    
    perrnum = ct.pointer(ct.c_int(0))

    hpdll.c_haverGetCodes(codes, ct.c_char_p(pdatabase.encode()), ct.c_int(numcodes), perrnum)
    if perrnum.contents.value!=0:
        Haveraux.api_raiseError(perrnum.contents.value)

    # codes at this point has no len(); indexing out of bounds crashes Python
    codes = [codes[i].decode(errors='replace') for i in range(0,numcodes)]
    return codes
    
class ccodesOK(ct.Structure):
    _fields_ = [("codesOK"  , ct.c_int),
                ("nodb_idx" , ct.POINTER(ct.c_int)),
                ("novn_idx" , ct.POINTER(ct.c_int)),
                ("noif_idx" , ct.POINTER(ct.c_int))
               ]

def api_haverCheckCodes(codes, pdatabases, updblist, numudbs, numcodes):
    if pdatabases is None or numcodes is None:
        raise _HaverPkgError('(API:haverCheckCodes) Argument missing.')
    if (not isinstance(pdatabases, (list, tuple)) or \
        not isinstance(numcodes, (int, float)) or
        numcodes<=0):
        raise _HaverPkgError('(API:haverCheckCodes) Invalid argument.')
    
    erridx = ccodesOK(0, (ct.c_int * numcodes)(0), (ct.c_int * numcodes)(0), (ct.c_int * numcodes)(0))
    
    hpdll.c_haverCheckCodes.argtypes = (ct.POINTER(ccodesOK), ct.POINTER(ct.c_char_p), ct.POINTER(ct.c_char_p), ct.POINTER(ct.c_char_p),
                                        ct.c_int, ct.c_int, ct.POINTER(ct.c_int))
    hpdll.c_haverCheckCodes.restype = None

    bcodes      = [x.encode() for x in codes] # "b": bytes object
    bpdatabases = [x.encode() for x in pdatabases]
    bupdblist   = [x.encode() for x in updblist]
    ccodes = (ct.c_char_p * numcodes)()
    ccodes[:] = bcodes
    cpdatabases = (ct.c_char_p * numcodes)()
    cpdatabases[:] = bpdatabases
    cupdblist = (ct.c_char_p * len(updblist))()
    cupdblist[:] = bupdblist
    perrnum = ct.pointer(ct.c_int(0))

    hpdll.c_haverCheckCodes(ct.pointer(erridx), ccodes, cpdatabases, cupdblist, numudbs, numcodes, perrnum)
        # codes at this point has no len(); indexing out of bounds crashes Python
    if perrnum.contents.value!=0:
        Haveraux.api_raiseError(perrnum.contents.value)
    
    ok = [erridx.codesOK             , erridx.nodb_idx[0:numcodes],
          erridx.novn_idx[0:numcodes], erridx.noif_idx[0:numcodes]]
    return ok

class cinfo(ct.Structure):
    _fields_ = [("code"        , ct.POINTER(ct.c_char_p)),
                ("startdate"   , ct.POINTER(ct.c_int)),
                ("enddate"     , ct.POINTER(ct.c_int)),
                ("numobs"      , ct.POINTER(ct.c_int)),
                ("frequency"   , ct.POINTER(ct.c_int)),
                ("datetimemod" , ct.POINTER(ct.c_int)),
                ("magnitude"   , ct.POINTER(ct.c_int)),
                ("decprecision", ct.POINTER(ct.c_int)),
                ("diftype"     , ct.POINTER(ct.c_int)),
                ("aggtype"     , ct.POINTER(ct.c_int)),
                ("datatype"    , ct.POINTER(ct.c_char_p)),
                ("group"       , ct.POINTER(ct.c_char_p)),
                ("geography1"  , ct.POINTER(ct.c_char_p)),
                ("geography2"  , ct.POINTER(ct.c_char_p)),
                ("descriptor"  , ct.POINTER(ct.c_char_p)),
                ("shortsource" , ct.POINTER(ct.c_char_p)),
                ("longsource"  , ct.POINTER(ct.c_char_p))
               ]

def api_haverGetAllInfo(codes, pdatabases):
    if codes is None or pdatabases is None:
        raise _HaverPkgError('(API:haverGetAllInfo) Argument missing.')
    if type(codes)     !=list or len(codes     )==0 or \
       type(pdatabases)!=list or len(pdatabases)==0:
        raise _HaverPkgError('(API:haverGetAllInfo) Invalid argument.')

    updblist = Haveraux.uniqOrder(pdatabases)
    numudbs  = len(updblist)
    numconfirm = len(codes)
    numcodes   = len(codes)
    
    sbuf_code        = [ct.create_string_buffer(LEN_NAME) for i in range(numcodes)]
    info_code        = (ct.c_char_p * numcodes)(*map(ct.addressof, sbuf_code))
    sbuf_datatype    = [ct.create_string_buffer(LEN_DTYP) for i in range(numcodes)]
    info_datatype    = (ct.c_char_p * numcodes)(*map(ct.addressof, sbuf_datatype))
    sbuf_group       = [ct.create_string_buffer(LEN_GROUP) for i in range(numcodes)]
    info_group       = (ct.c_char_p * numcodes)(*map(ct.addressof, sbuf_group))
    sbuf_geography1  = [ct.create_string_buffer(LEN_GEO) for i in range(numcodes)]
    info_geography1  = (ct.c_char_p * numcodes)(*map(ct.addressof, sbuf_geography1))
    sbuf_geography2  = [ct.create_string_buffer(LEN_GEO) for i in range(numcodes)]
    info_geography2  = (ct.c_char_p * numcodes)(*map(ct.addressof, sbuf_geography2))
    sbuf_descriptor  = [ct.create_string_buffer(LEN_DEF) for i in range(numcodes)]
    info_descriptor  = (ct.c_char_p * numcodes)(*map(ct.addressof, sbuf_descriptor))
    sbuf_shortsource = [ct.create_string_buffer(LEN_SSRC) for i in range(numcodes)]
    info_shortsource = (ct.c_char_p * numcodes)(*map(ct.addressof, sbuf_shortsource))
    sbuf_longsource  = [ct.create_string_buffer(LEN_LSRC) for i in range(numcodes)]
    info_longsource  = (ct.c_char_p * numcodes)(*map(ct.addressof, sbuf_longsource))

    info = cinfo(  info_code,
                   (ct.c_int * numcodes)(0), 
                   (ct.c_int * numcodes)(0), 
                   (ct.c_int * numcodes)(0), 
                   (ct.c_int * numcodes)(0), 
                   (ct.c_int * numcodes)(0), 
                   (ct.c_int * numcodes)(0), 
                   (ct.c_int * numcodes)(0), 
                   (ct.c_int * numcodes)(0), 
                   (ct.c_int * numcodes)(0), 
                   info_datatype,
                   info_group,
                   info_geography1,
                   info_geography2,
                   info_descriptor,
                   info_shortsource,
                   info_longsource )
   
    hpdll.c_haverGetAllInfo.argtypes = (ct.POINTER(cinfo), ct.POINTER(ct.c_char_p), ct.POINTER(ct.c_char_p),
                                        ct.POINTER(ct.c_char_p), ct.c_int, ct.c_int, ct.POINTER(ct.c_int))
    hpdll.c_haverGetAllInfo.restype = None

    bcodes      = [x.encode() for x in codes] # "b": bytes object
    bpdatabases = [x.encode() for x in pdatabases]
    bupdblist   = [x.encode() for x in updblist]
    ccodes = (ct.c_char_p * numcodes)()
    ccodes[:] = bcodes
    cpdatabases = (ct.c_char_p * numcodes)()
    cpdatabases[:] = bpdatabases
    cupdblist = (ct.c_char_p * len(updblist))()
    cupdblist[:] = bupdblist
    perrnum = ct.pointer(ct.c_int(0))
    
    hpdll.c_haverGetAllInfo(ct.pointer(info), ccodes, cpdatabases, cupdblist, numudbs, numcodes, perrnum)
    if perrnum.contents.value!=0:
        Haveraux.api_raiseError(perrnum.contents.value)

    pinfo = {'database': [os.path.basename(x) for x in pdatabases]}
    pinfo['code']        = [info.code[i].decode().lower() for i in range(0,numcodes)]
    pinfo['datatype']    = [info.datatype[i].decode(errors='replace')     for i in range(0,numcodes)]
    pinfo['group']       = [info.group[i].decode(errors='replace')        for i in range(0,numcodes)]
    pinfo['geography1']  = [info.geography1[i].decode(errors='replace')   for i in range(0,numcodes)]
    pinfo['geography2']  = [info.geography2[i].decode(errors='replace')   for i in range(0,numcodes)]
    pinfo['descriptor']  = [info.descriptor[i].decode(errors='replace')   for i in range(0,numcodes)]
    pinfo['shortsource'] = [info.shortsource[i].decode(errors='replace')  for i in range(0,numcodes)]
    pinfo['longsource']  = [info.longsource[i].decode(errors='replace')   for i in range(0,numcodes)]

    pinfo['startdate']    = Haveraux.ymdToDt(info.startdate[0:numcodes])
        # converts from pointer to list
        # remember that length of pointer is unknown to Python
    pinfo['enddate']      = Haveraux.ymdToDt(info.enddate[0:numcodes])
    pinfo['numobs']       = info.numobs[0:numcodes]
    pinfo['frequency']    = info.frequency[0:numcodes]
    pinfo['datetimemod']  = [datetime.fromtimestamp(x) for x in info.datetimemod[0:numcodes]]
    pinfo['magnitude']    = info.magnitude[0:numcodes]
    pinfo['decprecision'] = info.decprecision[0:numcodes]
    pinfo['diftype']      = info.diftype[0:numcodes]
    pinfo['aggtype']      = info.aggtype[0:numcodes]

    df = pd.DataFrame.from_dict(pinfo)
    df[['frequency', 'magnitude', 'decprecision', 'diftype', 'aggtype']] = \
         df[['frequency', 'magnitude', 'decprecision', 'diftype', 'aggtype']].astype(np.int8)
    df['numobs']    = df['numobs'].astype(np.int32)
    # df = df.reindex(list(Haveraux.const_fields), axis=1)
    df = df.reindex(columns=list(Haveraux.const_fields))
    return df

def api_haverObsNum(codes, pdatabases, updblist, numcodes, ymdstart, ymdend, dlxfreq_in):
    if codes is None or pdatabases is None:
        raise _HaverPkgError('(API:haverObsNum) Argument missing.')
    if type(codes)     !=list or len(codes     )==0 or \
       type(pdatabases)!=list or len(pdatabases)==0:
        raise _HaverPkgError('(API:haverObsNum) Invalid argument.')
    numudbs  = len(updblist)
    
    hpdll.c_haverObsNum.argtypes = (ct.POINTER(ct.c_char_p), ct.POINTER(ct.c_char_p), ct.POINTER(ct.c_char_p),
                                    ct.c_int, ct.c_int,
                                    ct.POINTER(ct.c_int), ct.POINTER(ct.c_int), ct.POINTER(ct.c_int), ct.POINTER(ct.c_int))
    
    bcodes      = [x.encode() for x in codes] # "b": bytes object
    bpdatabases = [x.encode() for x in pdatabases]
    bupdblist   = [x.encode() for x in updblist]
    ccodes = (ct.c_char_p * numcodes)()
    ccodes[:] = bcodes
    cpdatabases = (ct.c_char_p * numcodes)()
    cpdatabases[:] = bpdatabases
    cupdblist = (ct.c_char_p * len(updblist))()
    cupdblist[:] = bupdblist
    pstart = ct.pointer(ct.c_int(ymdstart))
    pend   = ct.pointer(ct.c_int(ymdend))
    pfreq  = ct.pointer(ct.c_int(dlxfreq_in))
    perrnum = ct.pointer(ct.c_int(0))

    obsnum = hpdll.c_haverObsNum(ccodes, cpdatabases, cupdblist,
                               numudbs, numcodes,
                               pstart, pend, pfreq, perrnum)
    if perrnum.contents.value!=0:
        Haveraux.api_raiseError(perrnum.contents.value)
    
    return {'dlxstart': pstart.contents.value,
            'dlxend'  : pend.contents.value,
            'dlxfreq_out': pfreq.contents.value,
            'obsnum': obsnum}

# aggmode encoding:
#   DLXGet/SetAggregation uses 0-2
#   Python code uses 1-3
def api_dlxGetAggregation():
    aggnum = hpdll.dlxGetAggregation() + 1
    aggmode = Haveraux.const_map_aggmode_n2s[aggnum]
    return aggmode

def api_dlxSetAggregation(mode):
    aggnum = Haveraux.const_map_aggmode_s2n[mode]-1
    hpdll.dlxSetAggregation.argtypes = (ct.c_int,)
    rc = hpdll.dlxSetAggregation(ct.c_int(aggnum))
    if rc==-1:
        Haveraux.api_raiseError(20)

def api_haverGetData(codes, pdatabases, updblist, \
                     dlxstart, dlxend, dlxfreq_out, obsnum):
    
    numudbs  = len(updblist)
    numcodes = len(codes)
    
    data = (ct.c_double * (obsnum*numcodes))(0)
    
    hpdll.c_haverGetData.argtypes = (ct.POINTER(ct.c_double), ct.POINTER(ct.c_char_p),
                                     ct.POINTER(ct.c_char_p), ct.POINTER(ct.c_char_p),
                                     ct.c_int, ct.c_int,
                                     ct.c_int, ct.c_int, ct.c_int, ct.c_long, ct.POINTER(ct.c_int))
    hpdll.c_haverGetData.restype  = None

    bcodes      = [x.encode() for x in codes] # "b": bytes object
    bpdatabases = [x.encode() for x in pdatabases]
    bupdblist   = [x.encode() for x in updblist]
    ccodes = (ct.c_char_p * numcodes)()
    ccodes[:] = bcodes
    cpdatabases = (ct.c_char_p * numcodes)()
    cpdatabases[:] = bpdatabases
    cupdblist = (ct.c_char_p * len(updblist))()
    cupdblist[:] = bupdblist
    obsnum = ct.c_long(obsnum)  # value may be very large!
    perrnum = ct.pointer(ct.c_int(0))

    hpdll.c_haverGetData(data, ccodes, cpdatabases, cupdblist,
                         numudbs, numcodes,
                         dlxstart, dlxend, dlxfreq_out, obsnum, perrnum)
    if perrnum.contents.value!=0:
        Haveraux.api_raiseError(perrnum.contents.value)
    
    rawdata = {'data': data, 'obsnum': obsnum.value}
       
    return rawdata

def api_haverDateSeq(dlxstart, obsnum, dlxfreq_out):
    
    dateseq = (ct.c_int * obsnum)(0)

    hpdll.c_haverDateSeq.argtypes = (ct.POINTER(ct.c_int), ct.c_int, ct.c_int, ct.c_long)
    hpdll.c_haverDateSeq.restype  = None
    hpdll.c_haverDateSeq(dateseq, ct.c_int(dlxstart), ct.c_int(obsnum), ct.c_long(dlxfreq_out))
        # dateseq at this point has no len(); indexing out of bounds crashes Python
    # ds = [ds[i] for i in range(0,obsnum)]
    ds = dateseq[:obsnum]
    return ds

